import sys
import os
import requests
from bs4 import BeautifulSoup

from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QToolBar,
    QLineEdit, QAction, QMessageBox,
    QTextEdit, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QDialog
)

from PyQt5.QtWebEngineWidgets import QWebEngineView
from PyQt5.QtCore import QUrl


class Browser(QMainWindow):

    def __init__(self):
        super().__init__()

        self.setWindowTitle("Jas AI Browser")
        self.resize(1400, 900)

        # Browser view
        self.browser = QWebEngineView()

        home = os.path.abspath("home.html")
        self.browser.setUrl(QUrl.fromLocalFile(home))

        # Layout
        container = QWidget()
        self.layout = QHBoxLayout()

        self.layout.addWidget(self.browser, 4)

        # AI Sidebar
        self.chat_box = QTextEdit()
        self.chat_box.setReadOnly(True)

        self.chat_input = QLineEdit()
        send_button = QPushButton("Ask AI")

        # ENTER KEY SENDS MESSAGE
        self.chat_input.returnPressed.connect(self.ask_ai)
        send_button.clicked.connect(self.ask_ai)

        chat_layout = QVBoxLayout()
        chat_layout.addWidget(self.chat_box)
        chat_layout.addWidget(self.chat_input)
        chat_layout.addWidget(send_button)

        self.chat_widget = QWidget()
        self.chat_widget.setLayout(chat_layout)
        self.chat_widget.setMaximumWidth(350)

        self.layout.addWidget(self.chat_widget)

        container.setLayout(self.layout)
        self.setCentralWidget(container)

        self.ai_visible = True

        # Toolbar
        navbar = QToolBar()
        self.addToolBar(navbar)

        back_btn = QAction("Back", self)
        back_btn.triggered.connect(self.browser.back)
        navbar.addAction(back_btn)

        forward_btn = QAction("Forward", self)
        forward_btn.triggered.connect(self.browser.forward)
        navbar.addAction(forward_btn)

        reload_btn = QAction("Reload", self)
        reload_btn.triggered.connect(self.browser.reload)
        navbar.addAction(reload_btn)

        summarize_btn = QAction("AI Summarize", self)
        summarize_btn.triggered.connect(self.summarize_page)
        navbar.addAction(summarize_btn)

        toggle_ai = QAction("Toggle AI", self)
        toggle_ai.triggered.connect(self.toggle_ai_panel)
        navbar.addAction(toggle_ai)

        self.url_bar = QLineEdit()
        self.url_bar.returnPressed.connect(self.navigate_to_url)
        navbar.addWidget(self.url_bar)

        self.browser.urlChanged.connect(self.update_url)

    # Navigation
    def navigate_to_url(self):
        url = self.url_bar.text()
        if not url.startswith("http"):
            url = "https://" + url
        self.browser.setUrl(QUrl(url))

    def update_url(self, q):
        self.url_bar.setText(q.toString())

    # Toggle AI sidebar
    def toggle_ai_panel(self):
        if self.ai_visible:
            self.chat_widget.hide()
            self.ai_visible = False
        else:
            self.chat_widget.show()
            self.ai_visible = True

    # Scrollable summary window
    def summarize_page(self):
        url = self.browser.url().toString()

        try:
            response = requests.get(url, headers={"User-Agent": "Mozilla/5.0"})
            soup = BeautifulSoup(response.text, "html.parser")

            paragraphs = soup.find_all("p")

            text = ""
            for p in paragraphs:
                text += p.get_text() + "\n\n"

            if len(text) < 200:
                text = "Not enough readable text found."

            dialog = QDialog(self)
            dialog.setWindowTitle("AI Page Summary")
            dialog.resize(700, 500)

            layout = QVBoxLayout()

            summary_box = QTextEdit()
            summary_box.setReadOnly(True)
            summary_box.setText(text)

            layout.addWidget(summary_box)

            dialog.setLayout(layout)
            dialog.exec_()

        except Exception as e:
            QMessageBox.warning(self, "Error", str(e))

    # AI Chat
    def ask_ai(self):
        question = self.chat_input.text()

        if question == "":
            return

        url = self.browser.url().toString()

        try:
            response = requests.get(url, headers={"User-Agent": "Mozilla/5.0"})
            soup = BeautifulSoup(response.text, "html.parser")

            paragraphs = soup.find_all("p")

            text = ""
            for p in paragraphs:
                text += p.get_text() + " "

            answer = text[:800]

            self.chat_box.append("You: " + question)
            self.chat_box.append("AI: " + answer + "\n")

        except Exception as e:
            self.chat_box.append("Error: " + str(e))

        self.chat_input.clear()


app = QApplication(sys.argv)
QApplication.setApplicationName("Jas AI Browser")

window = Browser()
window.show()

sys.exit(app.exec_())